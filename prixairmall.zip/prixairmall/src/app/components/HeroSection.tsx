'use client';

import React, { useState, useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';


export default function HeroSection() {
  const [activeMode, setActiveMode] = useState<'shop' | 'lounge'>('shop');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLElement>(null);

  const handleModeSwitch = (mode: 'shop' | 'lounge') => {
    if (mode === activeMode) return;
    setIsTransitioning(true);
    setTimeout(() => {
      setActiveMode(mode);
      setIsTransitioning(false);
    }, 300);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const rect = heroRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      setMousePos({ x, y });
    };
    const hero = heroRef.current;
    hero?.addEventListener('mousemove', handleMouseMove);
    return () => hero?.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const shopContent = {
    eyebrow: 'Fresh · Premium · Daily',
    headline: 'Shop',
    headlineAccent: 'Fresh.',
    sub: 'Minna\'s most complete premium supermarket. Fresh produce, imported goods, and everyday essentials — all under one roof.',
    cta: 'Explore the Market',
    ctaHref: '#supermarket',
    image: "https://images.unsplash.com/photo-1672130085162-e77915e35331",
    imageAlt: 'Bright, well-lit premium supermarket interior with colorful fresh produce displays and clean white shelving',
    badge: '2 Locations in Minna'
  };

  const loungeContent = {
    eyebrow: 'Thursdays · 6 PM · Karaoke',
    headline: 'Experience',
    headlineAccent: 'the Night.',
    sub: 'Minna\'s most electric social lounge. Signature cocktails, live karaoke every Thursday, and an atmosphere that never sleeps.',
    cta: 'Reserve a Table',
    ctaHref: '#lounge',
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_18fdc30b7-1772286198578.png",
    imageAlt: 'Atmospheric dark lounge interior with warm amber lighting, stage microphones, and plush seating arrangements',
    badge: 'Mics ON Every Thursday'
  };

  const content = activeMode === 'shop' ? shopContent : loungeContent;

  return (
    <section
      ref={heroRef}
      id="hero"
      className="relative min-h-screen flex flex-col overflow-hidden"
      style={{ paddingTop: 0 }}>
      
      {/* Background layers */}
      <div className="absolute inset-0 z-0">
        <div
          className={`absolute inset-0 transition-opacity duration-700 ${activeMode === 'shop' ? 'opacity-100' : 'opacity-0'}`}>
          
          <AppImage
            src={shopContent.image}
            alt={shopContent.imageAlt}
            fill
            priority
            sizes="100vw"
            className="object-cover object-center" />
          
          <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-black/60 to-black/85" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent" />
        </div>
        <div
          className={`absolute inset-0 transition-opacity duration-700 ${activeMode === 'lounge' ? 'opacity-100' : 'opacity-0'}`}>
          
          <AppImage
            src={loungeContent.image}
            alt={loungeContent.imageAlt}
            fill
            sizes="100vw"
            className="object-cover object-center" />
          
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/65 to-black/90" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-transparent" />
        </div>
      </div>

      {/* Atmospheric blobs */}
      <div
        className="absolute w-[600px] h-[600px] rounded-full blob-gold pointer-events-none z-0 transition-all duration-1000"
        style={{
          top: '20%',
          left: activeMode === 'shop' ? '10%' : '60%',
          transform: `translate(${mousePos.x * 30}px, ${mousePos.y * 20}px)`,
          opacity: activeMode === 'shop' ? 0.6 : 0.8
        }}
        aria-hidden="true" />
      
      <div
        className="absolute w-[400px] h-[400px] rounded-full blob-warm pointer-events-none z-0"
        style={{
          bottom: '10%',
          right: '5%',
          transform: `translate(${mousePos.x * -20}px, ${mousePos.y * -15}px)`
        }}
        aria-hidden="true" />
      

      {/* Nav area padding */}
      <div className="relative z-10 flex flex-col flex-1 pt-24 pb-16 px-6 md:px-12 max-w-7xl mx-auto w-full">

        {/* Toggle switcher */}
        <div className="flex items-center justify-center md:justify-start mb-12 md:mb-16">
          <div className="glass-card rounded-full p-1 flex gap-1">
            <button
              onClick={() => handleModeSwitch('shop')}
              className={`px-5 py-2.5 rounded-full text-sm font-semibold tracking-wide transition-all duration-300 ${
              activeMode === 'shop' ? 'gold-gradient text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-foreground'}`
              }>
              
              🛒 Shop Fresh
            </button>
            <button
              onClick={() => handleModeSwitch('lounge')}
              className={`px-5 py-2.5 rounded-full text-sm font-semibold tracking-wide transition-all duration-300 ${
              activeMode === 'lounge' ? 'gold-gradient text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-foreground'}`
              }>
              
              🎤 Experience the Night
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className={`flex-1 flex flex-col justify-center transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
          {/* Eyebrow */}
          <div className="flex items-center gap-3 mb-6">
            <span className="relative flex h-2.5 w-2.5">
              <span className="ping-dot absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary" />
            </span>
            <span className="text-primary text-xs font-semibold uppercase tracking-[0.2em]">
              {content.eyebrow}
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-hero-xl font-black text-foreground mb-4 leading-none">
            {content.headline}{' '}
            <span className="gold-text">{content.headlineAccent}</span>
          </h1>

          {/* Sub */}
          <p className="text-foreground/70 text-lg md:text-xl font-light max-w-xl mb-10 leading-relaxed">
            {content.sub}
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <a
              href={content.ctaHref}
              className="group inline-flex items-center gap-3 gold-gradient text-primary-foreground px-7 py-4 rounded-full font-bold text-sm tracking-wide hover:shadow-2xl transition-all duration-300 hover:scale-105">
              
              <span>{content.cta}</span>
              <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
              </svg>
            </a>
            <a
              href="#find-us"
              className="inline-flex items-center gap-2 text-foreground/70 hover:text-foreground text-sm font-medium border border-foreground/20 hover:border-primary/50 px-6 py-4 rounded-full transition-all duration-300">
              
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
              </svg>
              Find a Location
            </a>
          </div>

          {/* Badge */}
          <div className="mt-10 inline-flex items-center gap-2 glass-card-light rounded-full px-4 py-2 w-fit">
            <span className="text-primary text-xs">✦</span>
            <span className="text-foreground/80 text-xs font-medium">{content.badge}</span>
          </div>
        </div>

        {/* Bottom scroll indicator */}
        <div className="flex justify-center mt-12">
          <a href="#supermarket" className="flex flex-col items-center gap-2 text-foreground/40 hover:text-primary transition-colors">
            <span className="text-xs uppercase tracking-widest font-medium">Scroll</span>
            <div className="w-px h-12 bg-gradient-to-b from-primary/60 to-transparent" />
          </a>
        </div>
      </div>

      {/* Dual-concept split line (decorative) */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent z-10" />
    </section>);

}