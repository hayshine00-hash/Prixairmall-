'use client';

import React, { useEffect, useRef } from 'react';

const branches = [
  {
    id: 'city-gate',
    name: 'Branch 1 — City Gate',
    address: 'Opposite State Secretariat, City Gate, Minna, Niger State',
    landmark: 'Opposite State Secretariat',
    hours: 'Open Daily · Until 11:00 PM',
    phones: ['0813 088 2207', '09096877777'],
    badge: 'City Gate',
    mapEmbed: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7906.123456789!2d6.5568!3d9.6139!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104dd5dc37afefb3%3A0x1b3c2c1e2e1b1b1b!2sMinna%2C+Niger+State!5e0!3m2!1sen!2sng!4v1715000000000',
    color: 'from-primary/20 to-transparent',
    icon: '🏛️',
  },
  {
    id: 'bosso',
    name: 'Branch 2 — Bosso',
    address: 'Opposite Emir Palace Junction, Bosso, Minna, Niger State',
    landmark: 'Opposite Emir Palace Junction',
    hours: 'Open Daily · Until 11:00 PM',
    phones: ['0813 088 2207', '09096877777'],
    badge: 'Bosso · Lounge Venue',
    mapEmbed: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7906.987654321!2d6.5368!3d9.6239!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104dd5dc37afefb3%3A0x1b3c2c1e2e1b1b1b!2sBosso%2C+Minna!5e0!3m2!1sen!2sng!4v1715000000001',
    color: 'from-accent/10 to-transparent',
    icon: '👑',
  },
];

export default function FindUsSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.fade-up, .scale-reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef?.current) observer?.observe(sectionRef?.current);
    return () => observer?.disconnect();
  }, []);

  return (
    <section id="find-us" ref={sectionRef} className="py-20 md:py-28 px-6 md:px-12 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-14">
        <div className="flex items-center gap-3 mb-5 fade-up stagger-1">
          <div className="h-px w-10 bg-primary" />
          <span className="text-primary text-xs font-semibold uppercase tracking-[0.2em]">Locations</span>
        </div>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <h2 className="text-section-xl font-black text-foreground max-w-md fade-up stagger-2">
            Find Us{' '}
            <span className="gold-text">in Minna.</span>
          </h2>
          <div className="flex items-center gap-3 fade-up stagger-3">
            <div className="flex items-center gap-2 glass-card rounded-full px-4 py-2.5">
              <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-foreground/80 text-sm font-medium">Open Daily · Closes 11 PM</span>
            </div>
          </div>
        </div>
      </div>
      {/* Branch cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        {branches?.map((branch, idx) => (
          <div
            key={branch?.id}
            className={`glass-card rounded-2xl overflow-hidden hover-lift scale-reveal stagger-${idx + 1} flex flex-col`}
          >
            {/* Map */}
            <div className="relative h-52 md:h-64 bg-muted overflow-hidden">
              <div className={`absolute inset-0 bg-gradient-to-br ${branch?.color} z-10 pointer-events-none`} />
              {/* Static map placeholder with visual treatment */}
              <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-muted to-secondary">
                <div className="text-center">
                  <div className="text-4xl mb-3">{branch?.icon}</div>
                  <p className="text-foreground/60 text-sm font-medium">{branch?.landmark}</p>
                  <p className="text-muted-foreground text-xs mt-1">Minna, Niger State</p>
                  {/* Map grid lines decoration */}
                  <div className="absolute inset-0 opacity-10" style={{
                    backgroundImage: 'linear-gradient(rgba(200,150,90,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(200,150,90,0.5) 1px, transparent 1px)',
                    backgroundSize: '40px 40px'
                  }} />
                </div>
              </div>
              {/* Badge */}
              <div className="absolute top-4 left-4 z-20 glass-card-light rounded-full px-3 py-1.5 flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="ping-dot absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                </span>
                <span className="text-primary text-xs font-bold uppercase tracking-wide">{branch?.badge}</span>
              </div>
            </div>

            {/* Info */}
            <div className="p-6 md:p-7 flex flex-col flex-1 justify-between gap-5">
              <div>
                <h3 className="text-foreground text-lg font-bold mb-2">{branch?.name}</h3>
                <div className="flex items-start gap-2.5 mb-3">
                  <svg className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                  </svg>
                  <p className="text-muted-foreground text-sm leading-relaxed">{branch?.address}</p>
                </div>
                <div className="flex items-center gap-2.5">
                  <svg className="w-4 h-4 text-primary flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-muted-foreground text-sm">{branch?.hours}</p>
                </div>
              </div>

              {/* Phone numbers */}
              <div className="flex flex-col gap-2">
                {branch?.phones?.map((phone) => (
                  <a
                    key={phone}
                    href={`tel:${phone?.replace(/\s/g, '')}`}
                    className="flex items-center gap-3 glass-card rounded-xl px-4 py-3 hover:border-primary/40 transition-all group"
                  >
                    <div className="w-8 h-8 gold-gradient rounded-lg flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 text-primary-foreground" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                      </svg>
                    </div>
                    <span className="text-foreground font-semibold text-sm group-hover:text-primary transition-colors">{phone}</span>
                    <svg className="w-4 h-4 text-muted-foreground ml-auto group-hover:text-primary transition-all group-hover:translate-x-0.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                    </svg>
                  </a>
                ))}
              </div>

              {/* Get Directions */}
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(branch?.address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 border border-primary/30 hover:border-primary hover:bg-primary/10 text-primary rounded-xl py-3 text-sm font-semibold transition-all"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.75V15m6-6v8.25m.503 3.498l4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 00-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497z" />
                </svg>
                Get Directions
              </a>
            </div>
          </div>
        ))}
      </div>
      <div className="section-divider mt-20" />
    </section>
  );
}