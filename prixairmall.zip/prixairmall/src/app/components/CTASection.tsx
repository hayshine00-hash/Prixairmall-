'use client';

import React, { useEffect, useRef, useState } from 'react';

const stats = [
{ value: '2', label: 'Locations', suffix: '' },
{ value: '1000', label: 'Products', suffix: '+' },
{ value: '11', label: 'PM Close', suffix: '' },
{ value: '52', label: 'Karaoke Nights/Year', suffix: '+' }];


const instagramPosts = [
{
  id: 1,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_127c599b1-1776296415771.png",
  alt: 'Vibrant karaoke night crowd with colorful stage lights and people singing on stage',
  caption: 'Mics ON Thursday 🎤',
  likes: '312'
},
{
  id: 2,
  image: "https://images.unsplash.com/photo-1664138303860-11d1abbbc1ee",
  alt: 'Colorful fresh produce display with bright overhead lighting in supermarket',
  caption: 'Fresh arrivals 🥦',
  likes: '189'
},
{
  id: 3,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1ae818a7e-1772201512441.png",
  alt: 'Elegant lounge seating with warm amber lighting and sophisticated interior design',
  caption: 'Friday vibes ✨',
  likes: '445'
},
{
  id: 4,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1cfc197be-1772201512453.png",
  alt: 'Colorful cocktails and mocktails arranged on bar counter with ambient lighting',
  caption: 'Cocktail hour 🍹',
  likes: '278'
},
{
  id: 5,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1960d751f-1767797898872.png",
  alt: 'Premium supermarket aisle with international brands and clean organized shelving',
  caption: 'New imports in 🛒',
  likes: '156'
},
{
  id: 6,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1ee7d6d39-1769499983064.png",
  alt: 'Beautifully plated Nigerian jollof rice and chicken dish with garnish on dark plate',
  caption: 'Tonight\'s special 🍽️',
  likes: '521'
}];


function CountUp({ target, suffix }: {target: number;suffix: string;}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !started.current) {
          started.current = true;
          const duration = 1500;
          const steps = 40;
          const increment = target / steps;
          let current = 0;
          const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
              setCount(target);
              clearInterval(timer);
            } else {
              setCount(Math.floor(current));
            }
          }, duration / steps);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return <span ref={ref}>{count}{suffix}</span>;
}

export default function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.fade-up, .scale-reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 80);
            });
          }
        });
      },
      { threshold: 0.08 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="cta" ref={sectionRef} className="py-16 md:py-24 relative overflow-hidden">
      {/* Atmospheric background */}
      <div className="absolute inset-0 pointer-events-none z-0" aria-hidden="true">
        <div className="blob-gold absolute w-[700px] h-[700px] rounded-full" style={{ top: '-20%', left: '50%', transform: 'translateX(-50%)', opacity: 0.15 }} />
      </div>

      <div className="relative z-10 px-6 md:px-12 max-w-7xl mx-auto">

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-16 md:mb-20">
          {stats.map((stat, i) =>
          <div key={stat.label} className={`glass-card rounded-2xl p-5 md:p-6 text-center hover-lift scale-reveal stagger-${i + 1}`}>
              <div className="text-4xl md:text-5xl font-black gold-text mb-1">
                <CountUp target={parseInt(stat.value)} suffix={stat.suffix} />
              </div>
              <p className="text-muted-foreground text-xs md:text-sm font-medium uppercase tracking-wide">{stat.label}</p>
            </div>
          )}
        </div>

        {/* Instagram section */}
        <div className="mb-16 fade-up stagger-1">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 gold-gradient rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </div>
              <div>
                <p className="text-foreground font-bold text-sm">@prixairminna</p>
                <p className="text-muted-foreground text-xs">Follow us on Instagram</p>
              </div>
            </div>
            <a
              href="https://instagram.com/prixairminna"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary text-sm font-semibold hover:underline flex items-center gap-1">
              
              View All
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
              </svg>
            </a>
          </div>

          <div className="grid grid-cols-3 md:grid-cols-6 gap-2 md:gap-3">
            {instagramPosts.map((post, i) =>
            <a
              key={post.id}
              href="https://instagram.com/prixairminna"
              target="_blank"
              rel="noopener noreferrer"
              className={`relative rounded-xl overflow-hidden aspect-square group scale-reveal stagger-${i + 1}`}>
              
                <img
                src={post.image}
                alt={post.alt}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                loading="lazy" />
              
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all duration-300 flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity text-center p-2">
                    <p className="text-white text-xs font-semibold leading-tight">{post.caption}</p>
                    <p className="text-primary text-xs mt-1">❤️ {post.likes}</p>
                  </div>
                </div>
              </a>
            )}
          </div>
        </div>

        {/* Final CTA banner */}
        <div className="relative rounded-3xl overflow-hidden fade-up stagger-2">
          <div className="absolute inset-0 gold-gradient gradient-shift opacity-90" />
          <div className="absolute inset-0 opacity-5" style={{
            backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")'
          }} />

          <div className="relative z-10 px-8 md:px-16 py-12 md:py-16 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-center md:text-left">
              <p className="text-primary-foreground/70 text-xs font-bold uppercase tracking-[0.2em] mb-3">PrixairMall · Minna</p>
              <h2 className="text-primary-foreground text-3xl md:text-5xl font-black leading-tight mb-3">
                Visit Us Tonight.
              </h2>
              <p className="text-primary-foreground/80 text-base md:text-lg max-w-md leading-relaxed">
                Shop fresh. Stay for the night. Minna&apos;s finest experience awaits.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
              <a
                href="tel:08130882207"
                className="inline-flex items-center gap-2 bg-primary-foreground text-primary px-6 py-3.5 rounded-full font-bold text-sm hover:shadow-2xl transition-all hover:scale-105">
                
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                </svg>
                Call Now
              </a>
              <a
                href="#lounge"
                className="inline-flex items-center gap-2 border-2 border-primary-foreground/40 text-primary-foreground px-6 py-3.5 rounded-full font-bold text-sm hover:bg-primary-foreground/10 transition-all">
                
                Book a Table
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>);

}