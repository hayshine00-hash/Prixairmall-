'use client';

import React, { useState, useEffect } from 'react';

export default function FloatingCallButton() {
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-6 right-4 z-50 flex flex-col items-end gap-3 md:hidden">
      {expanded && (
        <div className="flex flex-col gap-2 items-end animate-[fadeIn_0.2s_ease]">
          <a
            href="tel:08130882207"
            className="flex items-center gap-2 glass-card border border-primary/30 rounded-full px-4 py-2.5 text-foreground text-sm font-semibold hover:border-primary transition-all"
          >
            <span>0813 088 2207</span>
          </a>
          <a
            href="tel:09096877777"
            className="flex items-center gap-2 glass-card border border-primary/30 rounded-full px-4 py-2.5 text-foreground text-sm font-semibold hover:border-primary transition-all"
          >
            <span>09096877777</span>
          </a>
          <a
            href="#reservation"
            onClick={() => setExpanded(false)}
            className="flex items-center gap-2 glass-card border border-primary/30 rounded-full px-4 py-2.5 text-primary text-sm font-semibold hover:border-primary transition-all"
          >
            <span>🎤 Book Karaoke Night</span>
          </a>
        </div>
      )}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-14 h-14 gold-gradient rounded-full flex items-center justify-center shadow-2xl karaoke-pulse transition-transform hover:scale-110 active:scale-95"
        aria-label="Call PrixairMall"
      >
        {expanded ? (
          <svg className="w-6 h-6 text-primary-foreground" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg className="w-6 h-6 text-primary-foreground" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
          </svg>
        )}
      </button>
    </div>
  );
}