'use client';

import React, { useState, useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';

interface FormState {
  name: string;
  phone: string;
  date: string;
  guests: string;
  note: string;
}

const menuHighlights = [
{ category: 'Cocktails & Mocktails', items: ['Prixair Gold Rush', 'Midnight Mule', 'Minna Sunset', 'Sparkling Hibiscus'], icon: '🍹' },
{ category: 'Small Chops & Starters', items: ['Peppered Gizzard', 'Suya Skewers', 'Spring Rolls', 'Puff Puff Trio'], icon: '🍢' },
{ category: 'Mains', items: ['Jollof Rice & Chicken', 'Fried Rice Deluxe', 'Grilled Tilapia', 'Pasta Primavera'], icon: '🍽️' },
{ category: 'Desserts', items: ['Pineapple Cake', 'Chocolate Fondue', 'Ice Cream Tower', 'Fruit Platter'], icon: '🍰' }];


export default function LoungeSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [formState, setFormState] = useState<FormState>({ name: '', phone: '', date: '', guests: '2', note: '' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.fade-up, .scale-reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 100);
            });
          }
        });
      },
      { threshold: 0.08 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <section id="lounge" ref={sectionRef} className="py-20 md:py-28 relative overflow-hidden">
      {/* Background atmosphere */}
      <div className="absolute inset-0 z-0 pointer-events-none" aria-hidden="true">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
        <div className="blob-gold absolute w-[500px] h-[500px] rounded-full" style={{ top: '10%', left: '-10%', opacity: 0.3 }} />
        <div className="blob-warm absolute w-[400px] h-[400px] rounded-full" style={{ bottom: '10%', right: '-5%', opacity: 0.2 }} />
      </div>

      <div className="relative z-10 px-6 md:px-12 max-w-7xl mx-auto">
        {/* Section header */}
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-5 fade-up stagger-1">
            <div className="h-px w-10 bg-primary" />
            <span className="text-primary text-xs font-semibold uppercase tracking-[0.2em]">Lounge & Restaurant</span>
          </div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <h2 className="text-section-xl font-black text-foreground max-w-lg fade-up stagger-2">
              Where Minna{' '}
              <span className="gold-text">Comes Alive.</span>
            </h2>
            <p className="text-muted-foreground text-base md:text-lg max-w-sm leading-relaxed fade-up stagger-3">
              Signature cocktails, great food, live entertainment, and the best karaoke night in town.
            </p>
          </div>
        </div>

        {/* BENTO GRID — Lounge */}
        {/* STEP 1: 4 cards: KaraokeNight(cs-2), AtmosphereCard(cs-1), MenuCard(cs-1), ReservationCard(cs-2) */}
        {/* STEP 2: Row1: [col1+2: KaraokeNight cs-2] [col3: AtmosphereCard cs-1] */}
        {/*         Row2: [col1: MenuCard cs-1] [col2+3: ReservationCard cs-2] */}
        {/* STEP 3: Placed 4/4 ✓ */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">

          {/* Card 1: KaraokeNight — col-span-2 */}
          <div className="md:col-span-2 relative rounded-2xl overflow-hidden min-h-[340px] scale-reveal stagger-1 group">
            <AppImage
              src="https://img.rocket.new/generatedImages/rocket_gen_img_10f501376-1772489659928.png"
              alt="Energetic dark concert venue with stage lights, microphone stands, and excited crowd in warm amber glow"
              fill
              sizes="(max-width: 768px) 100vw, 66vw"
              className="object-cover object-center transition-transform duration-700 group-hover:scale-105" />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-black/20" />
            <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-between">
              <div className="flex items-start justify-between">
                <div className="karaoke-pulse glass-card-light rounded-2xl px-4 py-3 flex items-center gap-3">
                  <span className="text-2xl">🎤</span>
                  <div>
                    <p className="text-primary text-xs font-bold uppercase tracking-widest">Mics ON</p>
                    <p className="text-foreground text-sm font-semibold">Karaoke Night</p>
                  </div>
                </div>
                <div className="glass-card rounded-xl px-3 py-2 text-center">
                  <p className="text-primary text-xs font-bold uppercase">Every</p>
                  <p className="text-foreground text-lg font-black">Thursday</p>
                  <p className="text-foreground/70 text-xs">6:00 PM</p>
                </div>
              </div>
              <div>
                <h3 className="text-foreground text-2xl md:text-4xl font-black mb-2 leading-tight">
                  Sing Your Heart Out
                </h3>
                <p className="text-foreground/70 text-sm md:text-base leading-relaxed max-w-md">
                  Minna&apos;s most anticipated weekly event. Grab the mic, choose your song, and let the night take over.
                </p>
                <a
                  href="#reservation"
                  className="inline-flex items-center gap-2 gold-gradient text-primary-foreground px-5 py-2.5 rounded-full text-sm font-bold mt-4 hover:shadow-lg transition-all hover:scale-105">
                  
                  Reserve Your Spot
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Card 2: AtmosphereCard — col-span-1 */}
          <div className="md:col-span-1 relative rounded-2xl overflow-hidden min-h-[340px] scale-reveal stagger-2 group">
            <AppImage
              src="https://images.unsplash.com/photo-1668502522603-d8b03d3e8c98"
              alt="Luxurious lounge interior with plush velvet seating, warm mood lighting, and elegant bar setup in deep amber tones"
              fill
              sizes="(max-width: 768px) 100vw, 33vw"
              className="object-cover object-center transition-transform duration-700 group-hover:scale-105" />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
            <div className="absolute inset-0 p-6 flex flex-col justify-end">
              <h3 className="text-foreground text-xl font-bold mb-1.5">The Atmosphere</h3>
              <p className="text-foreground/70 text-sm leading-relaxed">
                Plush seating, mood lighting, and a vibe that makes every night feel special.
              </p>
            </div>
          </div>

          {/* Card 3: MenuCard — col-span-1 */}
          <div className="md:col-span-1 glass-card rounded-2xl p-6 min-h-[300px] scale-reveal stagger-3 flex flex-col">
            <h3 className="text-foreground text-xl font-bold mb-4">Menu Highlights</h3>
            <div className="flex flex-col gap-3 flex-1">
              {menuHighlights.map((section) =>
              <div key={section.category} className="glass-card rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-base">{section.icon}</span>
                    <span className="text-primary text-xs font-bold uppercase tracking-wide">{section.category}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {section.items.slice(0, 2).map((item) =>
                  <span key={item} className="text-foreground/70 text-xs bg-muted px-2 py-0.5 rounded-full">{item}</span>
                  )}
                    <span className="text-muted-foreground text-xs px-2 py-0.5">+{section.items.length - 2} more</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Card 4: ReservationCard — col-span-2 */}
          <div id="reservation" className="md:col-span-2 glass-card rounded-2xl p-6 md:p-8 min-h-[300px] scale-reveal stagger-4">
            {submitted ?
            <div className="h-full flex flex-col items-center justify-center text-center py-8">
                <div className="w-16 h-16 gold-gradient rounded-full flex items-center justify-center mb-4 float-medium">
                  <svg className="w-8 h-8 text-primary-foreground" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                  </svg>
                </div>
                <h3 className="text-foreground text-2xl font-black mb-2">Reservation Received!</h3>
                <p className="text-muted-foreground text-sm max-w-sm leading-relaxed">
                  We&apos;ll confirm your table via phone. See you Thursday at 6 PM! 🎤
                </p>
                <button
                onClick={() => setSubmitted(false)}
                className="mt-5 text-primary text-sm font-medium hover:underline">
                
                  Make another reservation
                </button>
              </div> :

            <>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-foreground text-xl font-bold">Reserve for Karaoke Night</h3>
                    <p className="text-muted-foreground text-sm mt-1">Every Thursday · 6:00 PM · Bosso Branch</p>
                  </div>
                  <span className="text-2xl float-slow">🎤</span>
                </div>
                <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-muted-foreground text-xs font-semibold uppercase tracking-wide">Full Name</label>
                    <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState((p) => ({ ...p, name: e.target.value }))}
                    placeholder="Fatima Umar"
                    className="bg-muted border border-border rounded-xl px-4 py-3 text-foreground text-sm placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors" />
                  
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-muted-foreground text-xs font-semibold uppercase tracking-wide">Phone Number</label>
                    <input
                    type="tel"
                    required
                    value={formState.phone}
                    onChange={(e) => setFormState((p) => ({ ...p, phone: e.target.value }))}
                    placeholder="0813 088 2207"
                    className="bg-muted border border-border rounded-xl px-4 py-3 text-foreground text-sm placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors" />
                  
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-muted-foreground text-xs font-semibold uppercase tracking-wide">Date</label>
                    <input
                    type="date"
                    required
                    value={formState.date}
                    onChange={(e) => setFormState((p) => ({ ...p, date: e.target.value }))}
                    className="bg-muted border border-border rounded-xl px-4 py-3 text-foreground text-sm focus:outline-none focus:border-primary transition-colors" />
                  
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-muted-foreground text-xs font-semibold uppercase tracking-wide">Number of Guests</label>
                    <select
                    value={formState.guests}
                    onChange={(e) => setFormState((p) => ({ ...p, guests: e.target.value }))}
                    className="bg-muted border border-border rounded-xl px-4 py-3 text-foreground text-sm focus:outline-none focus:border-primary transition-colors">
                    
                      {['1', '2', '3', '4', '5', '6', '7', '8+'].map((g) =>
                    <option key={g} value={g}>{g} {g === '1' ? 'Guest' : 'Guests'}</option>
                    )}
                    </select>
                  </div>
                  <div className="sm:col-span-2 flex flex-col gap-1.5">
                    <label className="text-muted-foreground text-xs font-semibold uppercase tracking-wide">Special Request (Optional)</label>
                    <textarea
                    value={formState.note}
                    onChange={(e) => setFormState((p) => ({ ...p, note: e.target.value }))}
                    placeholder="Birthday celebration, dietary requirements..."
                    rows={2}
                    className="bg-muted border border-border rounded-xl px-4 py-3 text-foreground text-sm placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none" />
                  
                  </div>
                  <div className="sm:col-span-2">
                    <button
                    type="submit"
                    disabled={submitting}
                    className="w-full gold-gradient text-primary-foreground py-3.5 rounded-xl font-bold text-sm tracking-wide hover:shadow-xl transition-all duration-300 hover:scale-[1.02] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                    
                      {submitting ?
                    <>
                          <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                          </svg>
                          Sending...
                        </> :

                    <>Confirm Reservation 🎤</>
                    }
                    </button>
                  </div>
                </form>
              </>
            }
          </div>
        </div>
      </div>

      <div className="section-divider mt-20 mx-6 md:mx-12" />
    </section>);

}