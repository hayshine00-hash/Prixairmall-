'use client';

import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';

const bentoCards = [
{
  id: 'fresh-produce',
  colSpan: 'md:col-span-2',
  rowSpan: '',
  title: 'Farm-Fresh Produce',
  desc: 'Sourced daily — fruits, vegetables, herbs, and dairy. If it\'s in season, we have it.',
  badge: 'Daily Arrivals',
  image: "https://images.unsplash.com/photo-1648869745637-1c1a9ec2c3e9",
  imageAlt: 'Bright well-lit market display of colorful fresh fruits and vegetables in organized wooden crates',
  accent: true,
  stat: '500+ SKUs'
},
{
  id: 'new-arrivals',
  colSpan: 'md:col-span-1',
  rowSpan: '',
  title: 'New Arrivals',
  desc: 'Imported snacks, beverages, and specialty goods updated every week.',
  badge: '🆕 This Week',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_19d4d03da-1772739740937.png",
  imageAlt: 'Neatly arranged imported packaged goods and specialty beverages on modern supermarket shelves',
  accent: false,
  stat: 'Weekly Drops'
},
{
  id: 'grocery-categories',
  colSpan: 'md:col-span-1',
  rowSpan: '',
  title: 'Every Category',
  desc: 'Pantry staples, household items, personal care, frozen foods, and more.',
  badge: null,
  image: null,
  imageAlt: null,
  accent: false,
  stat: null,
  isCategories: true
},
{
  id: 'daily-deals',
  colSpan: 'md:col-span-2',
  rowSpan: '',
  title: 'Premium Brands, Honest Prices',
  desc: 'Quality you can trust at prices that make sense. Shop with confidence every visit.',
  badge: '⭐ Best Value',
  image: "https://images.unsplash.com/photo-1618106437472-5bd505bf1a79",
  imageAlt: 'Clean bright supermarket aisle with premium branded products neatly arranged on white shelves',
  accent: false,
  stat: 'Open 7 Days'
}];


const categories = [
{ icon: '🥩', label: 'Meat & Seafood' },
{ icon: '🥛', label: 'Dairy & Eggs' },
{ icon: '🍞', label: 'Bakery' },
{ icon: '🧴', label: 'Personal Care' },
{ icon: '🧹', label: 'Household' },
{ icon: '🧃', label: 'Beverages' },
{ icon: '🍫', label: 'Snacks' },
{ icon: '❄️', label: 'Frozen Foods' }];


export default function SupermarketSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.fade-up, .scale-reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 80);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef?.current) observer?.observe(sectionRef?.current);
    return () => observer?.disconnect();
  }, []);

  return (
    <section id="supermarket" ref={sectionRef} className="py-20 md:py-28 px-6 md:px-12 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="mb-14 md:mb-18">
        <div className="flex items-center gap-3 mb-5 fade-up stagger-1">
          <div className="h-px w-10 bg-primary" />
          <span className="text-primary text-xs font-semibold uppercase tracking-[0.2em]">Supermarket</span>
        </div>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <h2 className="text-section-xl font-black text-foreground max-w-lg fade-up stagger-2">
            Everything You Need,{' '}
            <span className="gold-text">Every Day.</span>
          </h2>
          <p className="text-muted-foreground text-base md:text-lg max-w-sm leading-relaxed fade-up stagger-3">
            Two fully stocked branches — Bosso Emir Palace Junction and City Gate. Open daily until 11 PM.
          </p>
        </div>
      </div>
      {/* Bento Grid — 3 columns */}
      {/* STEP 1: 4 cards: FreshProduce(cs-2), NewArrivals(cs-1), GroceryCategories(cs-1), DailyDeals(cs-2) */}
      {/* STEP 2: Row1: [col1+2: FreshProduce cs-2] [col3: NewArrivals cs-1] */}
      {/*         Row2: [col1: GroceryCategories cs-1] [col2+3: DailyDeals cs-2] */}
      {/* STEP 3: Placed 4/4 ✓ */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">

        {/* Card 1: FreshProduce — col-span-2 */}
        <div className="md:col-span-2 relative rounded-2xl overflow-hidden min-h-[280px] md:min-h-[320px] hover-lift scale-reveal stagger-1 group cursor-pointer">
          <AppImage
            src="https://images.unsplash.com/photo-1648869745637-1c1a9ec2c3e9"
            alt="Bright well-lit market display of colorful fresh fruits and vegetables in organized wooden crates"
            fill
            sizes="(max-width: 768px) 100vw, 66vw"
            className="object-cover object-center transition-transform duration-700 group-hover:scale-105" />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
          <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-between">
            <div className="flex items-start justify-between">
              <span className="glass-card-light text-primary text-xs font-bold uppercase tracking-wide px-3 py-1.5 rounded-full">
                Daily Arrivals
              </span>
              <span className="text-foreground/90 text-sm font-semibold glass-card px-3 py-1.5 rounded-full">500+ SKUs</span>
            </div>
            <div>
              <h3 className="text-foreground text-2xl md:text-3xl font-bold mb-2">Farm-Fresh Produce</h3>
              <p className="text-foreground/70 text-sm md:text-base leading-relaxed max-w-sm">
                Sourced daily — fruits, vegetables, herbs, and dairy. If it&apos;s in season, we have it.
              </p>
            </div>
          </div>
        </div>

        {/* Card 2: NewArrivals — col-span-1 */}
        <div className="md:col-span-1 relative rounded-2xl overflow-hidden min-h-[280px] hover-lift scale-reveal stagger-2 group cursor-pointer">
          <AppImage
            src="https://img.rocket.new/generatedImages/rocket_gen_img_19d4d03da-1772739740937.png"
            alt="Neatly arranged imported packaged goods and specialty beverages on modern supermarket shelves"
            fill
            sizes="(max-width: 768px) 100vw, 33vw"
            className="object-cover object-center transition-transform duration-700 group-hover:scale-105" />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
          <div className="absolute inset-0 p-6 flex flex-col justify-between">
            <span className="glass-card-light text-primary text-xs font-bold uppercase tracking-wide px-3 py-1.5 rounded-full w-fit">
              🆕 This Week
            </span>
            <div>
              <h3 className="text-foreground text-xl font-bold mb-1.5">New Arrivals</h3>
              <p className="text-foreground/70 text-sm leading-relaxed">
                Imported snacks, beverages, and specialty goods updated every week.
              </p>
            </div>
          </div>
        </div>

        {/* Card 3: GroceryCategories — col-span-1 */}
        <div className="md:col-span-1 glass-card rounded-2xl p-6 md:p-7 min-h-[260px] hover-lift scale-reveal stagger-3 flex flex-col justify-between">
          <div>
            <h3 className="text-foreground text-xl font-bold mb-1.5">Every Category</h3>
            <p className="text-muted-foreground text-sm mb-5 leading-relaxed">Pantry staples, household, personal care, frozen foods, and more.</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {categories?.map((cat) =>
            <div key={cat?.label} className="flex items-center gap-2 glass-card rounded-lg px-3 py-2">
                <span className="text-base">{cat?.icon}</span>
                <span className="text-foreground/80 text-xs font-medium">{cat?.label}</span>
              </div>
            )}
          </div>
        </div>

        {/* Card 4: DailyDeals — col-span-2 */}
        <div className="md:col-span-2 relative rounded-2xl overflow-hidden min-h-[260px] hover-lift scale-reveal stagger-4 group cursor-pointer">
          <AppImage
            src="https://images.unsplash.com/photo-1618106437472-5bd505bf1a79"
            alt="Clean bright supermarket aisle with premium branded products neatly arranged on white shelves"
            fill
            sizes="(max-width: 768px) 100vw, 66vw"
            className="object-cover object-center transition-transform duration-700 group-hover:scale-105" />
          
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
          <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-between">
            <span className="glass-card-light text-primary text-xs font-bold uppercase tracking-wide px-3 py-1.5 rounded-full w-fit">
              ⭐ Best Value
            </span>
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
              <div>
                <h3 className="text-foreground text-2xl md:text-3xl font-bold mb-2">Premium Brands, Honest Prices</h3>
                <p className="text-foreground/70 text-sm md:text-base max-w-sm leading-relaxed">
                  Quality you can trust at prices that make sense.
                </p>
              </div>
              <div className="flex items-center gap-2 glass-card px-4 py-3 rounded-xl w-fit">
                <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="text-foreground text-sm font-semibold">Open until 11 PM</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Bottom divider */}
      <div className="section-divider mt-20" />
    </section>);

}