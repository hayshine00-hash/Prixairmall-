import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/app/components/HeroSection';
import SupermarketSection from '@/app/components/SupermarketSection';
import LoungeSection from '@/app/components/LoungeSection';
import FindUsSection from '@/app/components/FindUsSection';
import CTASection from '@/app/components/CTASection';
import FloatingCallButton from '@/app/components/FloatingCallButton';
import ScrollAnimationInit from '@/app/components/ScrollAnimationInit';

export default function HomePage() {
  return (
    <>
      <div className="noise-overlay" aria-hidden="true" />
      <Header />
      <main>
        <HeroSection />
        <SupermarketSection />
        <LoungeSection />
        <FindUsSection />
        <CTASection />
      </main>
      <Footer />
      <FloatingCallButton />
      <ScrollAnimationInit />
    </>
  );
}